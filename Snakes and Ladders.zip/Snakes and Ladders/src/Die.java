import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;
import javax.swing.*;

public class Die extends JPanel {
    Board board;

    public Die(Board b)
    {
        board = b;
        button.addActionListener(new ButtonListener());
        add(button);
        add(dieRoll);
        add(playerLabel);
        add(info);
    }

    JLabel dieRoll = new JLabel("");   // JLabel: https://docs.oracle.com/javase/7/docs/api/javax/swing/JLabel.html
    JLabel playerLabel = new JLabel();
    JButton button = new JButton("Roll die");
    JLabel info = new JLabel("");



    public void paintComponent(Graphics page){
        super.paintComponent(page);
    }


    private class ButtonListener implements ActionListener  // die button
    {
        // check if player has won the game, after die roll, the current player changes- the previous player would have won
        private void winCondition(int currentPlayer) {
            int previousPlayer = currentPlayer - 1; // previous player
            if (currentPlayer == 0) {    // if player 1, previous player is player 4
                previousPlayer = 3;
            }

            if (board.user[previousPlayer].position == 100) {
                button.setText(previousPlayer + " won!");
                button.setEnabled(false);   // print that the player who got to 100 won
            }
        }

        private int rollDie() {
            Random rand = new Random();
            int roll = rand.nextInt(6) + 1;
            board.dieRolled(roll);  // rolled value onto the board
            return roll;
        }

        public void updateDisplay(int roll, int currentPlayer){
            dieRoll.setText("Rolled value: " + Integer.toString(roll)); // printing rolled value on panel
            playerLabel.setText("   Current player: " + Integer.toString(currentPlayer));
            info.setText("    Black line = snake" + "    White line = ladder");
        }

        // the method that responds to the button pushed
        public void actionPerformed(ActionEvent event) {
            int roll = rollDie();
            updateDisplay(roll, board.currentUserIndex);
            winCondition(board.currentUserIndex);
            getParent().repaint();  // to paint mainPanel so that the boardPanel works https://docs.oracle.com/javase/7/docs/api/java/awt/Component.html#getParent()
        }
    }
}
