import javafx.scene.shape.Circle;

import javax.swing.*;
import java.awt.*;
import java.util.Random;
/*
    This class is the GUI class.
 */

    public class BoardPanel extends JPanel {
        int[][] colorGrid;  // board is a 2D array
        Board board;

        private int totalRows = 10, yellow = 0, red = 1, blue = 2, green = 3;   // colors are random numbers

        public BoardPanel(Board b)
        {
            // Initializing color board
            board = b;
            int rowStart = 0;
            colorGrid = new int[totalRows][totalRows];  // 10 x 10 board
            for (int i = 0; i < totalRows; i++){
                int color = rowStart;
                for (int j = 0; j < totalRows; j++){ // assigning the colors
                    colorGrid[i][j] = color;
                    color = (color + 1) % 4;
                }
                rowStart = (rowStart + 1) % 4;
            }
        }


        // This method fills colors in the grid
        public void colorGrid(Graphics page) {
            int size = getSquareSize();
            for (int i = 0; i < totalRows; i++) {
                for (int j = 0; j < totalRows; j++) {
                    if (colorGrid[i][j] == yellow) {    // use 4 colors to distinguish the squares
                        page.setColor(Color.yellow);
                        page.fillRect(j * size, i * size, size, size);
                    } else if (colorGrid[i][j] == red) {
                        page.setColor(Color.red);
                        page.fillRect(j * size, i * size, size, size);
                    } else if (colorGrid[i][j] == blue) {
                        page.setColor(Color.blue);
                        page.fillRect(j * size, i * size, size, size);
                    } else if (colorGrid[i][j] == green) {
                        page.setColor(Color.green);
                        page.fillRect(j * size, i * size, size, size);
                    }
                }
            }
        }

        // this method gets the width and height of each square
        public int getSquareSize() {
            int size;
            if (getWidth() > getHeight()){  // so that the width and height are equal; square
                size = getHeight();
            } else {
                size = getWidth();
            }
            size = size / totalRows;    // size is 10
            return size;
        }

        // This method creates the numbers on the board
        private void numbers(Graphics page) {
            page.setColor(Color.black);
            int size = getSquareSize();
            for (int i = 0; i < totalRows; i++) {
                for (int j = 0; j < totalRows; j++) {
                    String text = Integer.toString(map(i, j));  // i, j coordinate

                    page.drawString(text, j * size, (i + 1) * size);  // increase the number by 1 each time it prints
                }
            }
        }

        // This method colors in the position of the users
        public void userPosition(Graphics page) {
            int size = getSquareSize();
            for (int i = 0; i < totalRows; i++) {
                for (int j = 0; j < totalRows; j++) {
                    for (int k = 0; k < board.user.length; k++) {
                        if (map(i, j) == board.user[k].position) {   // if that is where the user lands on, color in the circle
                            if (k == 0) {   // user 1
                                page.setColor(Color.gray);
                            } else if (k == 1) { // user 2
                                page.setColor(Color.black);
                            } else if (k == 2) { // user 3
                                page.setColor(Color.white);
                            } else if (k == 3) { // user 4
                                page.setColor(Color.magenta);
                            }
                            page.fillOval(j * size, i * size, size / 2, size / 2);  // coloring user
                        }
                    }
                }
            }
        }

        // This method paints the page
        public void paintComponent(Graphics page) {

            super.paintComponent(page);
            colorGrid(page);
            numbers(page);
            userPosition(page);

            for (int i = 0; i < board.snakes.length; i++){
                drawSnake(page, board.snakes[i]); // draw the array of snakes
            }
            for (int i = 0; i < board.ladders.length; i++){
                drawLadder(page, board.ladders[i]);   // draw the array of ladders
            }
        }

        // snakes
        private void drawSnake(Graphics page, Snake snake){
            int size = getSquareSize();
            int starti = 0;
            int startj = 0;

        // it finds the start coordinates of the snake
            for (int i = 0; i < totalRows; i++){
                for (int j = 0; j < totalRows; j++){
                    if (map(i, j) == snake.start){
                        starti = i;
                        startj = j;
                    }
                }
            }

            for (int i = 0; i < totalRows; i++){
                for (int j = 0; j < totalRows; j++){
                    if (map(i, j) == snake.end){
                        page.setColor(Color.black);
                        ((Graphics2D) page).setStroke(new BasicStroke(4));  // width of line: https://stackoverflow.com/questions/2839508/java2d-increase-the-line-width
                        page.drawLine((int)((startj + 0.5)* size), (int)((starti + 0.5) * size), (int)((j + 0.5) * size),(int)((i+0.5) * size)); // drawing snakes: the 0.5 draws the snake in the middle
                    }
                }
            }
        }

        // This method draws the ladders
        private void drawLadder(Graphics page, Ladders ladders){
            int size = getSquareSize();
            int starti = 0;
            int startj = 0;

            // This loop finds the start of the ladder
            for (int i = 0; i < totalRows; i++){
                for (int j = 0; j < totalRows; j++){
                    if (map(i, j) == ladders.start){
                        // start coordinates of ladders
                        starti = i;
                        startj = j;
                    }
                }
            }

            // this loop finds the end of the ladder and draws the ladders
            for (int i = 0; i < totalRows; i++){
                for (int j = 0; j < totalRows; j++){
                    if (map(i, j) == ladders.end){
                        page.setColor(Color.white);
                        page.drawLine((int)((startj + 0.5)* size),
                                (int)((starti + 0.5) * size), (int)((j + 0.5) * size),(int)((i+0.5) * size)); // drawing ladders
                    }
                }
            }
        }

        /*
            This method creates formulas that map the x,y coordinates to the number on the square
         */
        public int map(int i, int j){
            int formulaOdd = (9-i) * 10 + (j+1);    // formula for the rows that end in an odd number
            int formulaEven = (10-i) * 10 - j;   // formula for the rows that end in an even number
            if (i % 2 == 0){    // even row
                return formulaEven;
            } else {
                return formulaOdd;  // odd row
            }
        }
    }

