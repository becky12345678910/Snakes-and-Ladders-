import javax.swing.*;
import java.net.URL;
import java.net.MalformedURLException;

public class SnakesAndLadders {
/*
How the game should work:

Graphics:
-	The board
-	The die
-	The snakes and ladders
-	The users: in round disks
-	Four players

Function:
-	The board in 10 by 10
o	Colors: yellow, white, red, blue, green
-	There is one die
o	Color is white
-	Share instructions to users: When the disk lands in the base of the ladder, disk moves up and when disk lands on head of snake, disk moves down
-	User/users will enter name- when it is user’s turn, it will tell the specific user when to roll die
-	The die will roll by clicking it
-	The users, represented by the round disk will move automatically when the value of the die is shown
o	7 snakes in total
o	7 ladders in total

Considerations:
-	Two players are playing the game at the same time and sharing the same mouse
-	The player who rolls a 6 rolls again
*/

    public static void main(String[] args) {
        JFrame frame = new JFrame("Snakes and Ladders");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel mainPanel = new JPanel();    // mainPanel is a panel
        frame.add(mainPanel);   // adding mainPanel

        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.X_AXIS));    // So that the components line up horizontally from left to right:
        // https://docs.oracle.com/javase/7/docs/api/javax/swing/BoxLayout.html

        Board board = new Board();  // adding board
        BoardPanel boardPanel = new BoardPanel(board);  // adding board to the board panel
        Die die = new Die(board);   // adding board to the die panel

        mainPanel.add(boardPanel);  // adding boardPanel to the main panel
        mainPanel.add(die); // adding die to the main panel

        // try and catch- reading image: https://docs.oracle.com/javase/tutorial/2d/images/loadimage.html
        try {
            // the image: https://stackoverflow.com/questions/2935232/show-animated-gif
            URL url = new URL("https://www.charactersheet.net/img/sixsided.png");   // adding image to the program
            Icon icon = new ImageIcon(url);
            JLabel label = new JLabel(icon);
            die.add(label);
        } catch (MalformedURLException e){  // images always need MalformedURLException

        }
        frame.setSize(4000, 4000);  // setting size of frame
        frame.setVisible(true); // so it displays on the screen
    }
}
