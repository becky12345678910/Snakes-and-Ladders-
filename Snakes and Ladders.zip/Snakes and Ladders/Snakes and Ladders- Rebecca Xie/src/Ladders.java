public class Ladders {
    int start, end;

    public Ladders(int start, int end){
        this.start = start; // x, y coordinate of the start
        this.end = end; // x, y coordinate of the end
    }
}
