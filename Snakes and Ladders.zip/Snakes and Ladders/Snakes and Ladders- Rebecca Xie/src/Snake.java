public class Snake {
    int start, end;

    /*
    -	Placement of snakes: 23 back to 2, 50 back to 28, 63 back to 19, 77 back to 36, 93 back to 68, 95 back to 26, 98 back to 41
    -   7 snakes in total
    -	Placement of ladders: 1 up to 38, 4 up to 26, 21 up to 41, 26 up to 83, 52 up to 74, 72 up to 91, 83 up to 98
    -   7 ladders in total
    */

    public Snake(int start, int end){
        this.start = start; // x, y coordinate of the start
        this.end = end; // x, y coordinate of the end
    }
}
