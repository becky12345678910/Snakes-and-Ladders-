public class User {
    // the user moves the pieces
    // the user plays against other people : 2 players
    public int position;

    public User() {
        position = 1;   // both users start at 1 on the board
    }
}
