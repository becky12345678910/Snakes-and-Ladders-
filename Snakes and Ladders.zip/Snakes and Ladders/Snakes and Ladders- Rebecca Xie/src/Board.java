public class Board {

    int size;
    int currentUserIndex;
    Snake[] snakes = new Snake[7];
    Ladders[] ladders = new Ladders[7];
    User[] user = new User[4];

    public Board(){
        size = 10;  // board is 10x10

        // declaring users
        user[0] = new User();
        user[1] = new User();
        user[2] = new User();
        user[3] = new User();
        currentUserIndex = 0;  // what the current player is

        // declaring snakes
        snakes[0]= new Snake(39, 20);
        snakes[1] = new Snake(35, 17);
        snakes[2]= new Snake(74, 22);
        snakes[3]= new Snake(72, 6);
        snakes[4]= new Snake(93, 11);
        snakes[5]= new Snake(97, 76);
        snakes[6]= new Snake(77, 58);

        // declaring ladders
        ladders[0]= new Ladders(7, 24);
        ladders[1] = new Ladders(9, 31);
        ladders[2]= new Ladders(40, 69);
        ladders[3]= new Ladders(3, 13);
        ladders[4]= new Ladders(54, 75);
        ladders[5]= new Ladders(79, 88);
        ladders[6]= new Ladders(61, 92);
    }

    public void dieRolled(int roll){
        user[currentUserIndex].position += roll;    // roll increases the position of the user

        // user lands on snake
        for (int i = 0; i < snakes.length; i++) {
            if (user[currentUserIndex].position == snakes[i].start) {   // if user lands at snake, go down to the end coordinate of the snake
                user[currentUserIndex].position = snakes[i].end;
            }
        }

        // user lands on ladder
        for (int i = 0; i < ladders.length; i++) {
            if (user[currentUserIndex].position == ladders[i].start) {  // if user lands at ladder, go down to the end coordinate of the ladder
                user[currentUserIndex].position = ladders[i].end;
            }
        }

        // user lands on 100
        if (user[currentUserIndex].position > 100){
            user[currentUserIndex].position = 100;
        }

        // if it doesn't roll a 6, switch to other player
        if (roll != 6){
            currentUserIndex = (currentUserIndex + 1) % user.length;
        }
    }
}
