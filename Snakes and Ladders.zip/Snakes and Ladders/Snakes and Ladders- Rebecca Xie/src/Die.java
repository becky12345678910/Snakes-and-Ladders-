import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;
import javax.swing.*;

public class Die extends JPanel {
    Board board;

    public Die(Board b)
    {
        board = b;
        button.addActionListener(new ButtonListener());
        add(button);
        add(dieRoll);
        add(playerLabel);
    }

    JLabel dieRoll = new JLabel("");   // JLabel: https://docs.oracle.com/javase/7/docs/api/javax/swing/JLabel.html
    JLabel playerLabel = new JLabel();
    JButton button = new JButton("Roll die");


    public void paintComponent(Graphics page){
        super.paintComponent(page);
    }

    private class ButtonListener implements ActionListener
    {
        public void actionPerformed(ActionEvent event)
        {
            Random rand = new Random();
            int roll = rand.nextInt(6)+1;
            dieRoll.setText("Rolled value: " + Integer.toString(roll));

            board.dieRolled(roll);
            getParent().repaint();  // repainting

            int currentPlayer = board.currentUserIndex;
            playerLabel.setText("Current player: " + Integer.toString(currentPlayer));

            int previousPlayer = currentPlayer - 1;
            if (currentPlayer == 0){
                previousPlayer = 3;
            }

            if (board.user[previousPlayer].position == 100){
                button.setText(previousPlayer + " won!");
                //button.setEnabled(false);
            }
        }
    }
}
