import javafx.scene.shape.Circle;

import javax.swing.*;
import java.awt.*;
import java.util.Random;

    public class BoardPanel extends JPanel {
        int[][] colorGrid;
        Board board;

        private int totalRows = 10, yellow = 0, red = 1, blue = 2, green = 3;   // colors are random numbers

        public BoardPanel(Board b)
        {
            // Initializing color board
            board = b;
            int rowStart = 0;
            colorGrid = new int[totalRows][totalRows];  // 2D array because the colorGrid- board where user moves
            for (int i = 0; i < totalRows; i++){
                int color = rowStart;
                for (int j = 0; j < totalRows; j++){ // color grid
                    colorGrid[i][j] = color;
                    color = (color + 1) % 4;
                }
                rowStart = (rowStart + 1) % 4;
            }
        }

        public void paintComponent(Graphics page) {

            super.paintComponent(page);
            int size;
            if (getWidth() > getHeight()){
                size = getHeight();
            } else {
                size = getWidth();
            }

            size = size / totalRows;

            // color grid
            for (int i = 0; i < totalRows; i++) {
                for (int j = 0; j < totalRows; j++) {
                    if (colorGrid[i][j] == yellow) {
                        page.setColor(Color.yellow);
                        page.fillRect(j * size, i * size, size, size);
                    } else if (colorGrid[i][j] == red) {
                        page.setColor(Color.red);
                        page.fillRect(j * size, i * size, size, size);
                    } else if (colorGrid[i][j] == blue) {
                        page.setColor(Color.blue);
                        page.fillRect(j * size, i * size, size, size);
                    } else if (colorGrid[i][j] == green) {
                        page.setColor(Color.green);
                        page.fillRect(j * size, i * size, size, size);
                    }
                }
            }

            // numbers
            page.setColor(Color.black);
            for (int i = 0; i < totalRows; i++){
                for (int j = 0; j < totalRows; j++){
                    String text = Integer.toString(map(i, j));

                    page.drawString(text, j * size, (i+1) * size);
                }
            }

            // users
            for (int i = 0; i < totalRows; i++){
                for (int j = 0; j < totalRows; j++){
                    for (int k = 0; k < board.user.length; k++) {
                        if (map(i, j) == board.user[k].position){
                            if (k == 0) {
                                page.setColor(Color.gray);
                            } else if (k == 1){
                                page.setColor(Color.black);
                            } else if (k == 2){
                                page.setColor(Color.white);
                            } else if (k == 3){
                                page.setColor(Color.magenta);
                            }
                            page.fillOval(j * size, i * size, size / 2, size / 2);
                        }
                    }
                }
            }

            for (int i = 0; i < board.snakes.length; i++){
                drawSnake(page, size, board.snakes[i]);
            }
            for (int i = 0; i < board.ladders.length; i++){
                drawLadder(page, size, board.ladders[i]);
            }
        }

        // snakes
        private void drawSnake(Graphics page, int size, Snake snake){
            int starti = 0;
            int startj = 0;
            Graphics2D g = (Graphics2D)page;

            for (int i = 0; i < totalRows; i++){
                for (int j = 0; j < totalRows; j++){
                    if (map(i, j) == snake.start){
                        starti = i;
                        startj = j;
                    }
                }
            }

            for (int i = 0; i < totalRows; i++){
                for (int j = 0; j < totalRows; j++){
                    if (map(i, j) == snake.end){
                        page.setColor(Color.black);
                        ((Graphics2D) page).setStroke(new BasicStroke(5));  // https://stackoverflow.com/questions/2839508/java2d-increase-the-line-width
                        page.drawLine((int)((startj + 0.5)* size), (int)((starti + 0.5) * size), (int)((j + 0.5) * size),(int)((i+0.5) * size)); // drawing snakes
                    }
                }
            }
        }

        // ladders
        private void drawLadder(Graphics page, int size, Ladders ladders){
            int starti = 0;
            int startj = 0;

            for (int i = 0; i < totalRows; i++){
                for (int j = 0; j < totalRows; j++){
                    if (map(i, j) == ladders.start){
                        starti = i;
                        startj = j;
                    }
                }
            }

            for (int i = 0; i < totalRows; i++){
                for (int j = 0; j < totalRows; j++){
                    if (map(i, j) == ladders.end){
                        page.setColor(Color.white);
                        page.drawLine((int)((startj + 0.5)* size),
                                (int)((starti + 0.5) * size), (int)((j + 0.5) * size),(int)((i+0.5) * size)); // drawing ladders
                    }
                }
            }
        }

        public int map(int i, int j){
            int formulaOdd = (9-i) * 10 + (j+1);
            int formulaEven = (10-i) * 10 - j;
            if (i %2 == 0){
                return formulaEven;
            } else {
                return formulaOdd;
            }
        }
    }

