import javax.swing.*;
import java.net.URL;
import java.net.MalformedURLException;

public class SnakesAndLadders {
/*
How the game should work:

Graphics:
-	The board
-	The die
-	The snakes and ladders
-	The users: in round disks
-	Up to four players**

Function:
-	The board in 10 by 10
o	Colors: yellow, white, red, blue, green
-	There is one die
o	Color is white
-	Share instructions to users: When the disk lands in the base of the ladder, disk moves up and when disk lands on head of snake, disk moves down
-	User/users will enter name- when it is user’s turn, it will tell the specific user when to roll die
-	The die will roll by clicking it
-	The users, represented by the round disk will move automatically when the value of the die is shown
-	Placement of snakes: 23 back to 2, 50 back to 28, 63 back to 19, 77 back to 36, 93 back to 68, 95 back to 26, 98 back to 41
o	7 snakes in total
-	Placement of ladders: 1 up to 38, 4 up to 26, 21 up to 41, 26 up to 83, 52 up to 74, 72 up to 91, 83 up to 98
o	7 ladders in total

Considerations:
-	Two players are playing the game at the same time and sharing the same mouse
-	Two players have the same winning probability
*/

    public static void main(String[] args) {
        JFrame frame = new JFrame("Snakes and Ladders");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel mainPanel = new JPanel();    // mainPanel is a panel
        frame.add(mainPanel);   // adding mainPanel

        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.X_AXIS));    // So that the components line up horizontally from left to right:
        // https://docs.oracle.com/javase/7/docs/api/javax/swing/BoxLayout.html

        Board board = new Board();  // adding board
        BoardPanel boardPanel = new BoardPanel(board);  // adding board to the board panel
        Die die = new Die(board);   // adding die to the board panel

        mainPanel.add(boardPanel);  // adding boardPanel to the main panel
        mainPanel.add(die); // adding die to the main panel

        try {
            // https://stackoverflow.com/questions/2935232/show-animated-gif
            URL url = new URL("https://www.charactersheet.net/img/sixsided.png");   // adding image to the program
            Icon icon = new ImageIcon(url);
            JLabel label = new JLabel(icon);
            die.add(label);
        } catch (MalformedURLException e){

        }
        frame.setSize(2000, 2000);  // setting size of frame
        frame.setVisible(true); // so it displays on the screen
    }
}
